#pragma once
#include "stock_data.h"
#include <bits/stdc++.h>
Output basic(std::vector <StockData>,Input) ;

