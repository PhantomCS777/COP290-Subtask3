#pragma once 
#include "stock_data.h"
#include <bits/stdc++.h>

Output macd(std::vector <StockData>,Input);