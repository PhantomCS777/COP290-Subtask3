#pragma once
#include "stock_data.h"
#include <bits/stdc++.h>

Output DMA(std::vector <StockData>,Input) ;