#pragma once
#include "stock_data.h"
#include <bits/stdc++.h>

Output rsi(std::vector <StockData>,Input) ;