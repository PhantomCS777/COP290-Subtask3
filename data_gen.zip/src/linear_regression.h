#pragma once 
#include "stock_data.h"
#include <bits/stdc++.h>

Output linear_regression(std::vector <StockData> ,Input);

