#pragma once
#include "stock_data.h"
#include <bits/stdc++.h>

Output simple_pairs (std::vector <StockData> stockData1,std::vector <StockData> stockData2,Input) ;