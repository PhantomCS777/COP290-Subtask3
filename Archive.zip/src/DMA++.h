#pragma once
#include "stock_data.h"
#include <bits/stdc++.h>

Output modi_dma (std::vector <StockData>,Input) ;