#pragma once 
#include "stock_data.h"
#include <bits/stdc++.h>




Input input_basic(std::string symbol,std::string start_date,std::string end_date);