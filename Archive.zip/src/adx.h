#pragma once
#include "stock_data.h"
#include <bits/stdc++.h>
Output adx(std::vector <StockData>,Input);